export const NotFoundPage = () => {
  return (
    <div className="grid h-screen w-screen place-items-center">
      404 | Not Found
    </div>
  );
};
