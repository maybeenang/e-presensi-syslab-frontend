### How to run

Install [Node.js](https://nodejs.org/en/download/)

note: pastikan backend sudah berjalan

```bash
npm install
npm start
```

or

```bash
npm install
npm run build
npm run preview
```
